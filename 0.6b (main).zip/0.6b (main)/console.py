def loadconsolerequirments():
    import pygame

def openconsolewindow(size):
    #nextlmao
    pass